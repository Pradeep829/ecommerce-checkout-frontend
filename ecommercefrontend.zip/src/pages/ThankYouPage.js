import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import styles from './ThankYouPage.module.css'; // CSS Modules

const ThankYouPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [orderSummary, setOrderSummary] = useState(null);

  useEffect(() => {
    // Check if orderSummary data is passed via navigation state
    if (location.state && location.state.orderSummary) {
      setOrderSummary(location.state.orderSummary);
    } else {
      // If no data, it means user likely navigated directly or refreshed.
      // In a real app, you might try to fetch from DB using an order ID from URL param.
      // For this simulation, we redirect back to home.
      navigate('/');
    }
  }, [location.state, navigate]);

  if (!orderSummary) {
    return <div className={styles.loadingContainer}>Loading order details...</div>;
  }

  const isSuccess = orderSummary.transactionStatus === "Approved";

  return (
    <div className={`${styles.thankYouContainer} ${isSuccess ? styles.success : styles.failure}`}>
      {isSuccess ? (
        <h1 className={styles.thankYouTitle}>Thank You for Your Order!</h1>
      ) : (
        <h1 className={`${styles.thankYouTitle} ${styles.failureTitle}`}>Transaction Failed</h1>
      )}

      {isSuccess ? (
        <>
          <p className={styles.messageText}>Your order has been placed successfully.</p>
          <p className={styles.messageText}>A confirmation email has been sent to <strong>{orderSummary.customerInfo.email}</strong>.</p>
        </>
      ) : (
        <>
          <p className={styles.messageText}>Unfortunately, your transaction was <strong>{orderSummary.transactionStatus}</strong>.</p>
          <p className={styles.messageText}>{orderSummary.message || 'Please check your payment details or try again.'}</p>
          <p className={styles.supportText}>For assistance, please contact support.</p>
        </>
      )}

      <div className={styles.summaryDetails}>
        <h2 className={styles.summaryTitle}>Order Summary</h2>
        <p><strong>Order Number:</strong> {orderSummary.orderNumber}</p>
        
        <h3 className={styles.subSummaryTitle}>Product Details:</h3>
        <p><strong>Product:</strong> {orderSummary.productDetails.title}</p>
        <p><strong>Variant:</strong> {orderSummary.productDetails.selectedVariant?.value}</p>
        <p><strong>Quantity:</strong> {orderSummary.productDetails.quantity}</p>
        <p><strong>Subtotal:</strong> ${orderSummary.productDetails.subtotal?.toFixed(2)}</p>
        <p className={styles.totalPrice}><strong>Total:</strong> ${orderSummary.productDetails.total?.toFixed(2) || orderSummary.productDetails.subtotal?.toFixed(2)}</p>

        <h3 className={styles.subSummaryTitle}>Customer Information:</h3>
        <p><strong>Name:</strong> {orderSummary.customerInfo.fullName}</p>
        <p><strong>Email:</strong> {orderSummary.customerInfo.email}</p>
        <p><strong>Phone:</strong> {orderSummary.customerInfo.phoneNumber}</p>
        <p><strong>Address:</strong> {orderSummary.customerInfo.address}, {orderSummary.customerInfo.city}, {orderSummary.customerInfo.state}, {orderSummary.customerInfo.zipCode}</p>
      </div>

      <button className={styles.backHomeButton} onClick={() => navigate('/')}>
        Go to Home Page
      </button>
    </div>
  );
};

export default ThankYouPage;