import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import styles from './CheckoutPage.module.css'; // CSS Modules

const CheckoutPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);

  // --- Form Input States ---
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [transactionSimulation, setTransactionSimulation] = useState("1"); // 1: Approved, 2: Declined, 3: Gateway Error

  // --- Validation States ---
  const [errors, setErrors] = useState({});
  const [formSubmitted, setFormSubmitted] = useState(false); // To trigger validation on submit

  useEffect(() => {
    if (location.state && location.state.product) {
      setProduct(location.state.product);
    } else {
      // If no product data, redirect back to landing page or show an error
      navigate('/');
    }
  }, [location.state, navigate]);

  // --- Validation Logic ---
  const validateForm = () => {
    const newErrors = {};

    if (!fullName) newErrors.fullName = 'Full Name is required.';
    if (!email) {
      newErrors.email = 'Email is required.';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Email format is invalid.';
    }
    if (!phoneNumber) {
      newErrors.phoneNumber = 'Phone Number is required.';
    } else if (!/^\d{10}$/.test(phoneNumber)) { // Basic 10-digit validation
      newErrors.phoneNumber = 'Phone Number must be 10 digits.';
    }
    if (!address) newErrors.address = 'Address is required.';
    if (!city) newErrors.city = 'City is required.';
    if (!state) newErrors.state = 'State is required.';
    if (!zipCode) {
      newErrors.zipCode = 'Zip Code is required.';
    } else if (!/^\d{5}(-\d{4})?$/.test(zipCode)) { // Basic 5-digit or 5+4 zip code
      newErrors.zipCode = 'Zip Code format is invalid.';
    }

    if (!cardNumber) {
      newErrors.cardNumber = 'Card Number is required.';
    } else if (!/^\d{16}$/.test(cardNumber)) {
      newErrors.cardNumber = 'Card Number must be 16 digits.';
    }

    if (!expiryDate) {
      newErrors.expiryDate = 'Expiry Date is required.';
    } else {
      const [expMonth, expYear] = expiryDate.split('/').map(Number);
      const currentYear = new Date().getFullYear() % 100; // Get last two digits
      const currentMonth = new Date().getMonth() + 1; // getMonth() is 0-indexed

      if (
        isNaN(expMonth) || isNaN(expYear) ||
        expMonth < 1 || expMonth > 12 ||
        expYear < currentYear ||
        (expYear === currentYear && expMonth < currentMonth)
      ) {
        newErrors.expiryDate = 'Expiry Date must be a valid future date (MM/YY).';
      }
    }

    if (!cvv) {
      newErrors.cvv = 'CVV is required.';
    } else if (!/^\d{3}$/.test(cvv)) { // Basic 3-digit CVV
      newErrors.cvv = 'CVV must be 3 digits.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // --- Handlers ---
  const handleExpiryChange = (e) => {
    let value = e.target.value.replace(/\D/g, ''); // Remove non-digits
    if (value.length > 2) {
      value = value.substring(0, 2) + '/' + value.substring(2, 4); // Add slash after 2 digits
    }
    if (value.length > 5) {
      value = value.substring(0, 5); // Max MM/YY
    }
    setExpiryDate(value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormSubmitted(true); // Indicate form submission attempt

    const isValid = validateForm();
    if (!isValid) {
      alert('Please correct the form errors.');
      return;
    }

    if (!product) {
      alert('Product data missing. Please go back to the landing page.');
      navigate('/');
      return;
    }

    const checkoutData = {
      customerInfo: {
        fullName,
        email,
        phoneNumber,
        address,
        city,
        state,
        zipCode,
      },
      productDetails: {
        id: product.id,
        title: product.title,
        price: product.price,
        quantity: product.quantity,
        subtotal: product.subtotal,
        selectedVariant: product.selectedVariant,
      },
      paymentInfo: {
        cardNumber,
        expiryDate,
        cvv,
      },
      transactionSimulation: transactionSimulation,
    };

    try {
      // --- Backend Deployed URL ---
      const response = await fetch('https://ecommerce-backend-re1m.onrender.com/api/checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify(checkoutData),
      });

      const data = await response.json();

      if (response.ok) {
        console.log('Checkout successful:', data);
        navigate('/thank-you', {
          state: {
            orderSummary: {
              orderNumber: data.orderNumber,
              customerInfo: checkoutData.customerInfo,
              productDetails: checkoutData.productDetails,
              transactionStatus: data.transactionStatus, // "Approved"
              message: data.message,
            },
          },
        });
      } else {
        console.error('Checkout failed:', data);
        alert(`Order failed: ${data.message || 'Something went wrong. Please check console for details.'}`);
        navigate('/thank-you', {
          state: {
            orderSummary: {
              orderNumber: data.orderNumber || 'N/A', // Backend might not send order number on failure
              customerInfo: checkoutData.customerInfo,
              productDetails: checkoutData.productDetails,
              transactionStatus: data.transactionStatus, // "Declined" or "Gateway Error"
              message: data.message,
            },
          },
        });
      }
    } catch (error) {
      console.error('Error during checkout:', error);
      alert('An error occurred. Please check your internet connection and try again.');
      // Handle network errors (e.g., if backend is down)
      navigate('/thank-you', {
        state: {
          orderSummary: {
            orderNumber: 'N/A',
            customerInfo: checkoutData.customerInfo,
            productDetails: checkoutData.productDetails,
            transactionStatus: 'Network Error',
            message: 'A network error occurred. Please try again.',
          },
        },
      });
    }
  };

  if (!product) {
    return <div className={styles.loadingContainer}>Loading product details...</div>;
  }

  const { title, selectedVariant, quantity, subtotal, total } = product;

  return (
    <div className={styles.checkoutContainer}>
      <h1>Checkout</h1>
      <form onSubmit={handleSubmit} className={styles.checkoutForm}>
        <h2 className={styles.sectionTitle}>Customer Information</h2>
        <div className={styles.formGroup}>
          <label htmlFor="fullName">Full Name:</label>
          <input type="text" id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
          {formSubmitted && errors.fullName && <p className={styles.errorText}>{errors.fullName}</p>}
        </div>
        <div className={styles.formGroup}>
          <label htmlFor="email">Email:</label>
          <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          {formSubmitted && errors.email && <p className={styles.errorText}>{errors.email}</p>}
        </div>
        <div className={styles.formGroup}>
          <label htmlFor="phoneNumber">Phone Number:</label>
          <input type="tel" id="phoneNumber" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} required />
          {formSubmitted && errors.phoneNumber && <p className={styles.errorText}>{errors.phoneNumber}</p>}
        </div>
        <div className={styles.formGroup}>
          <label htmlFor="address">Address:</label>
          <input type="text" id="address" value={address} onChange={(e) => setAddress(e.target.value)} required />
          {formSubmitted && errors.address && <p className={styles.errorText}>{errors.address}</p>}
        </div>
        <div className={styles.formGroupGrid}>
          <div className={styles.formGroup}>
            <label htmlFor="city">City:</label>
            <input type="text" id="city" value={city} onChange={(e) => setCity(e.target.value)} required />
            {formSubmitted && errors.city && <p className={styles.errorText}>{errors.city}</p>}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="state">State:</label>
            <input type="text" id="state" value={state} onChange={(e) => setState(e.target.value)} required />
            {formSubmitted && errors.state && <p className={styles.errorText}>{errors.state}</p>}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="zipCode">Zip Code:</label>
            <input type="text" id="zipCode" value={zipCode} onChange={(e) => setZipCode(e.target.value)} required />
            {formSubmitted && errors.zipCode && <p className={styles.errorText}>{errors.zipCode}</p>}
          </div>
        </div>

        <h2 className={styles.sectionTitle}>Payment Information</h2>
        <div className={styles.formGroup}>
          <label htmlFor="cardNumber">Card Number (16-digit):</label>
          <input type="text" id="cardNumber" value={cardNumber} onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, '').substring(0, 16))} maxLength="16" required />
          {formSubmitted && errors.cardNumber && <p className={styles.errorText}>{errors.cardNumber}</p>}
        </div>
        <div className={styles.formGroupInline}>
          <div className={styles.formGroup}>
            <label htmlFor="expiryDate">Expiry Date (MM/YY):</label>
            <input type="text" id="expiryDate" value={expiryDate} onChange={handleExpiryChange} placeholder="MM/YY" maxLength="5" required />
            {formSubmitted && errors.expiryDate && <p className={styles.errorText}>{errors.expiryDate}</p>}
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="cvv">CVV (3-digit):</label>
            <input type="text" id="cvv" value={cvv} onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').substring(0, 3))} maxLength="3" required />
            {formSubmitted && errors.cvv && <p className={styles.errorText}>{errors.cvv}</p>}
          </div>
        </div>

        <h2 className={styles.sectionTitle}>Order Summary</h2>
        <div className={styles.orderSummary}>
          <p>Product: <strong>{title}</strong></p>
          <p>Variant: <strong>{selectedVariant.value}</strong></p>
          <p>Quantity: <strong>{quantity}</strong></p>
          <p>Subtotal: <strong>${subtotal?.toFixed(2)}</strong></p>
          <p className={styles.totalPrice}>Total: <strong>${total?.toFixed(2)}</strong></p>
        </div>

        <h2 className={styles.sectionTitle}>Transaction Simulation</h2>
        <div className={styles.formGroup}>
          <label htmlFor="transactionSimulation">Simulate Outcome:</label>
          <select id="transactionSimulation" value={transactionSimulation} onChange={(e) => setTransactionSimulation(e.target.value)}>
            <option value="1">1 (Approved)</option>
            <option value="2">2 (Declined)</option>
            <option value="3">3 (Gateway Error)</option>
          </select>
        </div>

        <button type="submit" className={styles.checkoutButton}>
          Complete Checkout
        </button>
      </form>
    </div>
  );
};

export default CheckoutPage;