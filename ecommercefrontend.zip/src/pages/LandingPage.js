import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './LandingPage.module.css'; // CSS Modules

// Mock product data (more products, dummy URLs)
const mockProducts = [
  {
    id: "prod_001",
    title: "Classic White Sneakers",
    description: "Timeless design with premium comfort for everyday wear. Lightweight and breathable, perfect for any casual occasion.",
    price: 89.99,
    imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8d2hpdGUlMjBzbmVha2Vyc3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60",
    variants: [
      { type: "color", value: "White", code: "white", hex: "#FFFFFF" },
      { type: "color", value: "Black", code: "black", hex: "#000000" },
      { type: "color", value: "Grey", code: "grey", hex: "#808080" },
    ],
  },
  {
    id: "prod_002",
    title: "Stylish Denim Jacket",
    description: "A classic denim jacket, perfect for layering and adding a touch of casual cool to any outfit. Durable and versatile for all seasons.",
    price: 120.00,
    imageUrl: "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8ZGVuaW0lMjBqYWNrZXR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60",
    variants: [
      { type: "size", value: "Small", code: "s" },
      { type: "size", value: "Medium", code: "m" },
      { type: "size", value: "Large", code: "l" },
      { type: "size", value: "X-Large", code: "xl" },
    ],
  },
  {
    id: "prod_003",
    title: "Minimalist Smartwatch",
    description: "Track your fitness and stay connected with this sleek, feature-packed smartwatch. Long-lasting battery and crystal-clear display.",
    price: 199.99,
    imageUrl: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c21hcnR3YXRjaHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60",
    variants: [
      { type: "band", value: "Leather", code: "leather" },
      { type: "band", value: "Silicone", code: "silicone" },
      { type: "band", value: "Metal Mesh", code: "metal" },
    ],
  },
  {
    id: "prod_004",
    title: "Noise-Cancelling Headphones",
    description: "Immersive audio experience with superior noise cancellation for your daily commute or focused work. Enjoy rich bass and clear highs.",
    price: 249.00,
    imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8aGVhZHBob25lc3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60",
    variants: [
      { type: "color", value: "Black", code: "black", hex: "#000000" },
      { type: "color", value: "Silver", code: "silver", hex: "#C0C0C0" },
      { type: "color", value: "Rose Gold", code: "rose_gold", hex: "#B76E79" },
    ],
  },
  {
    id: "prod_005",
    title: "Ergonomic Office Chair",
    description: "Designed for long hours of comfort and support, reducing back strain. Fully adjustable for personalized posture.",
    price: 350.00,
    imageUrl: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8ZXJnb25vbWljJTIwY2hhaXJ8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=500&q=60",
    variants: [
      { type: "material", value: "Mesh", code: "mesh" },
      { type: "material", value: "Leatherette", code: "leatherette" },
    ],
  },
  {
    id: "prod_006",
    title: "Portable Bluetooth Speaker",
    description: "Compact yet powerful speaker with crisp sound and deep bass. Waterproof design, perfect for outdoor adventures.",
    price: 79.99,
    imageUrl: "https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8Ymx1ZXRvb3RoJTIwc3BlYWtlcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60",
    variants: [
      { type: "color", value: "Blue", code: "blue", hex: "#0000FF" },
      { type: "color", value: "Black", code: "black", hex: "#000000" },
      { type: "color", value: "Red", code: "red", hex: "#FF0000" },
    ],
  },
];




const LandingPage = () => {
  const navigate = useNavigate();
  // State to manage selected variant and quantity for each product by its ID
  const [productSelections, setProductSelections] = useState(() => {
    // Initialize state with default selections for each product
    const initialSelections = {};
    mockProducts.forEach(product => {
      initialSelections[product.id] = {
        selectedVariant: product.variants[0],
        quantity: 1,
      };
    });
    return initialSelections;
  });

  const handleVariantChange = (productId, event) => {
    const product = mockProducts.find(p => p.id === productId);
    const selected = product.variants.find(v => v.code === event.target.value);
    setProductSelections(prev => ({
      ...prev,
      [productId]: {
        ...prev[productId],
        selectedVariant: selected,
      },
    }));
  };

  const handleQuantityChange = (productId, event) => {
    setProductSelections(prev => ({
      ...prev,
      [productId]: {
        ...prev[productId],
        quantity: Math.max(1, parseInt(event.target.value) || 1),
      },
    }));
  };

  const handleBuyNow = (productId) => {
    const product = mockProducts.find(p => p.id === productId);
    const selection = productSelections[productId];

    if (!selection || !product) {
      alert("Error: Product selection data missing.");
      return;
    }

    const subtotal = product.price * selection.quantity;
    const total = subtotal; // Assuming no taxes/shipping for simplicity

    navigate('/checkout', {
      state: {
        product: {
          ...product,
          selectedVariant: selection.selectedVariant,
          quantity: selection.quantity,
          subtotal: parseFloat(subtotal.toFixed(2)),
          total: parseFloat(total.toFixed(2)),
        },
      },
    });
  };

  return (
    <div className={styles.landingContainer}>
      <h1 className={styles.pageTitle}>Our Products</h1>
      <div className={styles.productsGrid}>
        {mockProducts.map((product) => {
          const currentSelection = productSelections[product.id];
          if (!currentSelection) return null; // Should not happen with proper initialization

          return (
            <div key={product.id} className={styles.productCard}>
              <div className={styles.productImage}>
                <img src={product.imageUrl} alt={product.title} />
              </div>
              <div className={styles.productDetails}>
                <h2 className={styles.productTitle}>{product.title}</h2>
                <p className={styles.productDescription}>{product.description}</p>
                <p className={styles.productPrice}>${product.price.toFixed(2)}</p>

                <div className={styles.variantSelector}>
                  <label htmlFor={`variant-${product.id}`}>{product.variants[0].type}:</label>
                  <select
                    id={`variant-${product.id}`}
                    value={currentSelection.selectedVariant.code}
                    onChange={(e) => handleVariantChange(product.id, e)}
                  >
                    {product.variants.map((variant) => (
                      <option key={variant.code} value={variant.code}>
                        {variant.value}
                      </option>
                    ))}
                  </select>
                  {currentSelection.selectedVariant.hex && (
                    <span className={styles.selectedColorPreview} style={{ backgroundColor: currentSelection.selectedVariant.hex }}></span>
                  )}
                </div>

                <div className={styles.quantitySelector}>
                  <label htmlFor={`quantity-${product.id}`}>Quantity:</label>
                  <input
                    type="number"
                    id={`quantity-${product.id}`}
                    min="1"
                    value={currentSelection.quantity}
                    onChange={(e) => handleQuantityChange(product.id, e)}
                  />
                </div>

                <button
                  className={styles.buyNowButton}
                  onClick={() => handleBuyNow(product.id)}
                >
                  Buy Now
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default LandingPage;